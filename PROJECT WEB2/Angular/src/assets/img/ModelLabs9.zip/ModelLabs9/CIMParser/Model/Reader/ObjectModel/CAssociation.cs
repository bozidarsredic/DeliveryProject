﻿namespace CIM.Model
{
    class CAssociation
    {

    }
}
